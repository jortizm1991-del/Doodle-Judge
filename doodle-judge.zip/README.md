# 👑 Doodle Judge

A party drawing game for phones, in the style of Apples to Apples. Each round one
player is the **judge**. Everyone else gets the same secret word and draws it at the
same time. The judge sees the drawings with no names, guesses the word, then crowns
the best (or funniest) drawing.

One phone hosts, everyone else joins with a room code or QR code. No app, no
computer, no server. The whole game is the single file `index.html`. It runs on the
same engine as Doodle Impostor.

## Put it online (GitHub Pages, about 5 minutes)

1. In GitHub, create a new **public** repository (for example `Doodle-Judge`).
2. Upload `index.html` to it (Add file → Upload files → Commit).
3. Go to **Settings → Pages**. Under "Build and deployment", choose
   **Deploy from a branch**, branch `main`, folder `/ (root)`, and tap **Save**.
4. After a minute or two, the game is at
   `https://<your-username>.github.io/Doodle-Judge/`.

It works the same on Vercel or any other static host.

## How to play

1. The host opens the page and taps **Host a game**. A room code and QR code appear.
2. Friends scan the QR code or open the page and type the code.
3. With 3 or more players, the host taps **Start game**.
4. Everyone **presses and holds** the dark card to see their secret privately, then taps
   **I'm ready**. The judge's card says they're the judge (plus the category, if that's on).
5. **Everyone draws at once** before the timer runs out. No letters or numbers.
   **Done ✓** finishes early; the round moves on as soon as everyone is done.
6. The judge sees all the drawings as cards **A, B, C…** with no names and guesses the word
   (everyone else can see the cards too, but no helping!).
7. The word is revealed and the judge taps **⭐ Crown** on their favorite drawing.
8. Results show whose drawing was whose, and the judge role moves to the next player.

**Tip:** an extra tablet, laptop or smart TV browser can join as a **big screen**
(on the join page). It shows the cards large and never shows the word early.

## Scoring

| What happened | Points |
|---|---|
| Judge guesses the word | **Every drawer +1, judge +2** |
| Your drawing is crowned ⭐ | +1 (to whoever really drew it) |
| 😈 Locked-out player names the saboteur | Locked-out player +1 |
| 😈 Locked-out player guesses wrong (or doesn't guess) | Saboteur +1 |
| 🃏 Judge guesses the odd one out's word | Odd one out +1 |

## Modes and settings (host, in the lobby)

- **Words / game mode** (same packs as Doodle Impostor):
  - 🎨 Normal (classic): all 10 everyday categories. This is the default.
  - 🎲 Mix of everything: Normal plus Easy, Kids and Hard (never 18+)
  - 🟢 Easy · 🧸 Kids · 🔴 Hard · 🔞 After Dark (18+)
  - any one of 10 categories (animals, food, house, places, jobs, sports, nature,
    things that move, clothes, spooky & fantasy), or ✏️ My own words
- **Judge guesses by:**
  - ⌨️ Typing it (default): 2 tries. Forgives capitals, accents, "the/a/el/la", plurals and
    small typos, and accepts the word in English or Spanish. If a guess was clearly right
    but didn't count, the host can tap **✓ Count the guess as right**.
  - 🔢 Picking from 8: one pick from 8 similar words. Easier.
- **😈 Saboteur** (off by default, 4+ players): one drawer secretly draws someone else's card
  as well as their own, switching between two tabs. That player is **locked out**: their
  phone shows their card being drawn live, and when the judge is crowning they pick who they
  think the saboteur is. If the saboteur's fake card gets crowned, the saboteur gets the point.
- **🃏 Odd one out** (off by default, 4+ players): one drawer secretly gets a different word
  from the same group, and doesn't know it. It's revealed in the results.
- **🌀 Twist:**
  - 🎨 Normal: no twist
  - 🙈 Blind drawing: you can't see your own drawing
  - ✍️ One line only: your card is done the moment you lift your finger
  - ⚡ Speed: 30 seconds to draw
  - 🔄 Pass it on: halfway through, every drawing is passed to someone else to finish.
    If it's crowned, both artists get the point. (The saboteur sits these rounds out.)
  - 🎲 Random: cycles through all of the above, Normal included, before any repeats
- **Draw time:** 45, 60 (default), 90 seconds or 2 minutes.
- **Rounds:** 👑×1 (everyone is the judge once, the default), 👑×2, 5, 8 or endless.
- **Judge sees category:** on by default.
- **Language:** English or Español. Words and every screen switch for all players.

## Drawing tools

Pen, paint bucket, eraser, undo and clear, with 16 colors and 4 brush sizes.

## Good to know

- **Every phone needs internet.** Messages go through free public MQTT relay services
  (HiveMQ, EMQX and Mosquitto), with automatic fallback if one is down. Names and
  drawings pass through them, so it's fine for a party game but not for private information.
- **Keep the host's screen open.** If the host's phone locks or reloads, the game picks up
  where it left off. A player who reloads mid-drawing gets their drawing back.
- People who join mid-round watch that round and play from the next one.
- The host can remove players (✕ in the lobby) and use the ☰ menu to skip a round or end the game.
- Up to 12 players.
